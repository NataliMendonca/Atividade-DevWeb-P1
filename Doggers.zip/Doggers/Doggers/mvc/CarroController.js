// import Crud from '../Crud'
import Crud from '../mvc/Crud.js'
import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url';
import bodyParser from 'body-parser';
// Opcional: Se precisar de suporte para métodos HTTP como DELETE em formulários
// import methodOverride from 'method-override';

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
const router = express.Router()

const crud = new Crud()

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname, '../../pages/public')))

app.post('/inserir', function(req, res) {
    const { id, val1, val2 } = req.body;
    const carro = { id: id ? parseInt(id) : undefined, nomecarro: val1, cor: val2 };

    crud.save(carro, function(carro) {
        if (carro) {
            res.json(carro);
        } else {
            res.status(404).json({ message: 'Carro não encontrado para atualização.' });
        }
    });
});

app.get('/select', function(req, res) {
    const id = req.query.id;

    crud.select(id, function(data) {
        if (data) {
            res.json(data);
        } else {
            res.status(404).json({ message: 'Carro não encontrado.' });
        }
    });
});

app.delete('/carros/:id', function(req, res) {
    const id = req.params.id;

    crud.delete(id, function(result) {
        if (result) {
            res.json({ success: true, message: 'Carro deletado com sucesso!' });
        } else {
            res.status(404).json({ success: false, message: 'Carro não encontrado.' });
        }
    });
});

app.get('/', function(req, res) {       
    res.send("Olá express");
});

let server = app.listen(3000, function() {
    let host = server.address().address;
    let port = server.address().port;
    console.log("Servidor iniciado em http://%s:%s", host, port);
});