import conn from './properties.js'

class Crud {

  static teste(){
    return "ok";
  }

  // Pega todos os registros
  getAllCars(callback){
    let sql = "SELECT * FROM carro";
    conn.query(sql, function(error, results, fields){
        if(error) throw error;
        callback(results);
    });
  }

  // Pega por Id
  getById(id, callback){
    let sql = "SELECT * FROM carro WHERE id = ?";
    conn.query(sql, id, function(error, results, fields){
      if(error) throw error;
      callback(results);
    });
  }

  // Pega pelo nome
  getByName(nomecarro, callback){
    let sql = "SELECT * FROM carro WHERE nomecarro = ?";
    conn.query(sql, nomecarro, function(error, results, fields){
      if(error) throw error;
      callback(results);
    });
  }

  // Salvar
  save(carro, callback){
    let sql = "INSERT INTO carro SET ?";
    conn.query(sql, carro, function(error, results, fields){
        if(error) throw error;

        carro.id = results.insertId;
        callback(carro);
    });
  }

  // Atualizar campos
  update(id, carro, callback){
    let sql = "UPDATE carro SET ? WHERE id = ?";
    conn.query(sql, [carro, id], function(error, results, fields){
      if(error) throw error;
      callback(results);
    });
  }

  // Apagar
  delete(id, callback){
    let sql = "DELETE FROM carro WHERE id = ?";
    conn.query(sql, id, function(error, results, fields){
      if(error) throw error;
      callback(results);
    });
  }

  selecionar(callback){
    let sql = "SELECT * FROM carro";
    conn.query(sql, function(error, results, fields){
      if(error) throw error;
      callback(results);
    });
  }
}

export default Crud;